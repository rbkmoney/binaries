<?php


if (! defined('DIAFAN'))
{
	$path = __FILE__; $i = 0;
	while(! file_exists($path.'/includes/404.php'))
	{
		if($i == 10) exit; $i++;
		$path = dirname($path);
	}
	include $path.'/includes/404.php';
}

class Payment_rbk_model extends Diafan
{

	public function get($params, $pay)
	{
		$result["pay"] = $pay;
        $result["eshopId"] = $params["eshopId"];
        $result["text"] = $pay["text"];
		$result["desc"] = $pay["desc"];
        //$result["curr"] = $params["curr"];
        $cart_rewrite = DB::query_result("SELECT rewrite FROM {rewrite} WHERE module_name='site' AND trash='0' AND element_type='element' AND element_id IN (SELECT id FROM {site} WHERE module_name='%s' AND [act]='1' AND trash='0')", $pay['module_name']);
        $result["successUrl"] = BASE_PATH_HREF.$cart_rewrite.'/step3/';
        $result["failUrl"] = BASE_PATH_HREF.$cart_rewrite.'/step4/';
		$result["summ"] = $pay["summ"];
        $result["orderId"] = $pay["element_id"];
        $result["siteName"] = $params["siteName"];
        
        $apiKey = $params["apiKey"];
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://api.rbk.money/v1/processing/invoices",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $this->prepare_postfields($params, $pay),
          CURLOPT_HTTPHEADER => $this->prepare_headers($apiKey),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);
        
        if ($err) {
          $result["err"] = "cURL Error #:" . $err;
        } else {
          $arr = json_decode($response, true); 
          $result["invoice"]["id"] = $arr["invoice"]["id"];
          $result["invoice"]["token"] = $arr["invoiceAccessToken"]["payload"];
          
          $result["inv"] = $arr;
        }
        
        
        //$result["hash"] = strtolower(md5($result["eshopId"].'::'.$result["summ"].'::'.$result["curr"].'::::::'.$result["orderId"].'::::'.$params["secretKey"]));

        
		return $result;
	}
    
    function prepare_postfields($params, $pay)
    {
        $arr = [];
        $arr["shopID"] = $params["eshopId"];
        $arr["dueDate"] = date("c", $pay["created"] + 3 * 24 * 3600);
        $arr["amount"] = intval($pay["summ"]*100);
        $arr["currency"] = 'RUB';
        $arr["product"] = 'Заказ номер '.$pay["element_id"];
        $arr["description"] = 'Заказ номер '.$pay["element_id"];
        $arr["metadata"]["order_id"] = $pay["element_id"];
        $arr["cart"] = [];
       
        foreach($pay["details"]["goods"] as $key => $row)
        {
            $arr["cart"][$key]["product"] = $row["name"];
            $arr["cart"][$key]["quantity"] = intval($row["count"]);
            $arr["cart"][$key]["price"] = intval($row["price"]*100);
            
        }
        
        $result = json_encode($arr);
        
      
        return $result;    
    }
    
    function prepare_headers($apiKey)
    {
        $headers = [];
        $headers[] = 'X-Request-ID: ' . uniqid();
        $headers[] = 'Authorization: Bearer ' . $apiKey;
        $headers[] = 'Content-type: application/json; charset=utf-8';
        $headers[] = 'Accept: application/json';
        return $headers;
    }
}