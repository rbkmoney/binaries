<?php

if (! defined('DIAFAN'))
{
	$path = __FILE__; $i = 0;
	while(! file_exists($path.'/includes/404.php'))
	{
		if($i == 10) exit; $i++;
		$path = dirname($path);
	}
	include $path.'/includes/404.php';
}

echo $result["text"];


echo '<form action="'.$result["successUrl"].'" method="GET">
    <script src="https://checkout.rbk.money/checkout.js" class="rbkmoney-checkout"
            data-invoice-id="'.$result["invoice"]["id"].'"
            data-invoice-access-token="'.$result["invoice"]["token"].'"          
            data-label="Оплатить с карты"
            data-name="'.$result["siteName"].'"
            data-description="Заказ номер '.$result["orderId"].'"
            data-pay-button-label="Оплатить">
    </script>
</form>';

