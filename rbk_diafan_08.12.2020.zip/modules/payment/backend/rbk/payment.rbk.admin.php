<?php


if (! defined('DIAFAN'))
{
	$path = __FILE__; $i = 0;
	while(! file_exists($path.'/includes/404.php'))
	{
		if($i == 10) exit; $i++;
		$path = dirname($path);
	}
	include $path.'/includes/404.php';
}

class Payment_rbk_admin
{
	public $config;

	public function __construct()
	{
		$this->config = array(
			"name" => 'RBK',
			"params" => array(
				'eshopId' => 'ID сайта',
                'apiKey' => 'API ключ',
                'siteName' => 'Название сайта',
                /*'curr' => 'Валюта'*/
			)
		);
	}
}