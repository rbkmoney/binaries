<?php


if (! defined('DIAFAN'))
{
	$path = __FILE__; $i = 0;
	while(! file_exists($path.'/includes/404.php'))
	{
		if($i == 10) exit; $i++;
		$path = dirname($path);
	}
	include $path.'/includes/404.php';
}

$pay = $this->diafan->_payment->check_pay($_POST['orderId'], 'rbk');
$this->diafan->_payment->success($pay);
/*$pay = $this->diafan->_payment->check_pay($_POST['orderId'], 'rbk');


$control_hash = strtolower(md5($pay["params"]["eshopId"].'::'.$_POST["summ"].'::'.$pay["params"]["curr"].'::::::'.$_POST["orderId"].'::::'.$pay["params"]["secretKey"]));

$hash = $_POST["hash"];

if($hash == $control_hash)
{
    $this->diafan->_payment->success($pay);    
}

$this->diafan->_payment->fail($pay);*/